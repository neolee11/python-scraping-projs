from main import addition

print(addition(5, 3))