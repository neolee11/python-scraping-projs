import requests

# r = requests.get('http://www.yahoo.com')
# print(r.content)
# print(r.status_code)

print('great')


def addition(a, b):
    """Add two numbers, and return their sum"""
    sum_result = a + b
    return sum_result


print(addition(3, 4))
