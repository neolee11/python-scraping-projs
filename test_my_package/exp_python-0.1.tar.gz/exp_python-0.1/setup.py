from setuptools import setup, find_packages

setup(name='exp_python',
      version='0.1',
      description='this is experimental',
      author='Daniel',
      packages=['exp_python']
      )

__author__ = 'Daniel'
